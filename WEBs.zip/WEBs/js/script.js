let myFirstVar = "hello world";

console.log(myFirstVar);